#library(EpiEstim)
library(lubridate)
library(dplyr)
library(ggplot2)
library(plotly)
library(epiR)
library(pracma)
library(RcppRoll)
library(e1071)
library(tidyverse)
library(survey)

correctedPrevalence = function(smallthresh = FALSE, adjustspec = FALSE, agesexn = TRUE)
{
  prev_df <- read.csv("sero_consolidated_weights.csv", stringsAsFactors = F)
  if(smallthresh)
    prev_df <- prev_df %>% mutate(covid_resultado = ifelse(covid_resultado_alt == "Positive", 1, 0))
  else
    prev_df <- prev_df %>% mutate(covid_resultado = ifelse(covid_resultado == "Positive", 1, 0))

  # Sensitivity and specificity
  

  if(smallthresh) {
    se = 0.925
    sp = 0.967
  }
  else {
    se = 0.84
    sp = 0.999
  }
  
  # Make weighted and unweighted survey object
  un_weighted_df <- svydesign(id = ~1, weights = ~1, data = prev_df)
  weighted_df <- survey::svydesign(id = ~1, weights = ~weights, data = prev_df)
  
  # Calculate prevlanece without weights 
  prev_unweighted <- svyby(~covid_resultado, 
                           by = ~location + donmo, 
                           design = un_weighted_df, 
                           FUN = svyciprop, method = "be", vartype = c("ci", "var")) %>% rename("var_unweighted" =  "var.as.numeric(covid_resultado)")
  
  # Calculate prevalence with weights
  prev_weighted <- svyby(~covid_resultado, 
                         by = ~location + donmo, 
                         design = weighted_df, 
                         FUN = svyciprop, method = "be", vartype = c("ci", "var")) %>% rename("var_weighted" =  "var.as.numeric(covid_resultado)")
  
  prevalence <- prev_unweighted %>% 
    rename(prev = covid_resultado) %>% 
    left_join(prev_weighted %>% 
                rename(
                  prev_weighted = covid_resultado,
                  ci_l_weighted = ci_l,
                  ci_u_weighted = ci_u
                ))
  
  # This is the same as what the epi.prev function does, Diggle is in reference
  # to the original paper that I took this from
  diggle_adjust <- function(p) {
    adj <- (p + sp - 1) / (se + sp - 1)
    adj <- ifelse(adj < 0, 0, adj)
    return(adj)
  }
  
  prevalence <- prevalence %>% 
    mutate(prev_weighted_adj = diggle_adjust(prev_weighted),
           ci_l_weighted_adj = diggle_adjust(ci_l_weighted),
           ci_u_weighted_adj = diggle_adjust(ci_u_weighted))
  
  prevalence <- prevalence %>% 
    mutate(prev_unweighted_adj = diggle_adjust(prev),
           ci_l_unweighted_adj = diggle_adjust(ci_l),
           ci_u_unweighted_adj = diggle_adjust(ci_u))
  
  # Attaches the sampling dates for each month
  sampling_dates <- prev_df %>%
    group_by(location, donmo) %>% 
    summarise(min_dt = min(donda), 
              max_dt = max(donda),
              med_dt = median(donda)) %>%
    mutate(min_dt = dmy(str_c(min_dt, donmo, "2020", sep = "-")),
           max_dt = dmy(str_c(max_dt, donmo, "2020", sep = "-")),
           med_dt = dmy(str_c(med_dt, donmo, "2020", sep = "-")))
  
  prevalence <- prevalence %>% 
    left_join(sampling_dates) %>% 
    arrange(location, donmo)
  
  prevalence = prev_df %>%  group_by(donmo, location) %>% summarize(n = n()) %>% merge(prevalence, by = c("donmo", "location"))
  
  if(adjustspec) {
    if(agesexn) {
    return(data.frame(donmo = prevalence$donmo, location = prevalence$location, n = prevalence$n, med_dt = prevalence$med_dt,
                    prev = prevalence$prev_weighted_adj, ci_l = prevalence$ci_l_weighted_adj, ci_u = prevalence$ci_u_weighted_adj,
                    var = prevalence$var_weighted))
    } else {
      return(data.frame(donmo = prevalence$donmo, location = prevalence$location, n = prevalence$n, med_dt = prevalence$med_dt,
                        prev = prevalence$prev_unweighted_adj, ci_l = prevalence$ci_l_unweighted_adj, ci_u = prevalence$ci_u_unweighted_adj,
                        var = prevalence$var_unweighted))
    }
  }
  else {
    if(agesexn) {
    return(data.frame(donmo = prevalence$donmo, location = prevalence$location, n = prevalence$n,  med_dt = prevalence$med_dt,
                      prev = prevalence$prev_weighted, ci_l = prevalence$ci_l_weighted, ci_u = prevalence$ci_u_weighted, 
                      var = prevalence$var_weighted))
    }
    else{
      return(data.frame(donmo = prevalence$donmo, location = prevalence$location, n = prevalence$n,  med_dt = prevalence$med_dt,
                        prev = prevalence$prev_unweighted, ci_l = prevalence$ci_l_unweighted, ci_u = prevalence$ci_u_unweighted,
                        var = prevalence$var_unweighted))
    }
  }
}

calculate.u = function(rho, alpha, delay = FALSE, K = 1)
{
  drho = diff(c(0, rho))
  #drho = c(0, diff(rho))
  #drho = c(0, 0, diff(rho[1:(length(rho)-1)]))
  A = matrix(0, nrow = length(drho), ncol = length(drho))
  for(i in 1:length(drho)) {
    A[i,i] = 1
    for(j in 1:length(drho)) {
      if(j < i - delay)
        A[i,j] = -K*alpha^(i-j)
    }
  }
  #u = pinv(A) %*% drho
  u = solve(A, drho)
  return(u)
}



calculate.alphamin = function(rho, delay = FALSE, K = 1)
{
  dalpha = 1E-3
  alpha = dalpha
  u = rep(-1, length(rho))
  while(any(u < 0) && alpha < 0.5)
  {
    alpha = alpha + dalpha
    u = calculate.u(rho, alpha, delay, K)
  }
  return(alpha)
}



calculate.alphamin.p = function(rho, delay = FALSE)
{
  dp = 1E-3
  p = dp
  dalpha = 1E-3
  alpha = dalpha
  u = rep(-1, length(rho))
  while(any(u < 0) && p < 1)
  {
    p = p + dp
    u = calculate.u(rho, alpha, delay, p0)
  }
  return(alpha)
}

exponential.model = function(u, alpha)
{
  shat =rep(0, length(u))
  for (i in 2:length(shat))
  {
    shat[i] = alpha*(shat[i-1] + u[i-1]) 
  }
  return(shat)
}

exponential.model.delay = function(u, alpha)
{
  shat =rep(0, length(u))
  for (i in 3:length(shat))
  {
    shat[i] = alpha*(shat[i-1] + u[i-2]) 
  }
  return(shat)
}

gamma.model = function(u, alpha1, alpha2)
{
  p = delay.signal(c(0, alpha1^(1:(length(u)-1))), alpha2)
  #p = c(0, dgamma(1:(length(u)-1), alpha1, alpha2))
  #p = p/sum(p)
  shat = conv(u,p)[1:length(p)]
  shat[1] = 0
  return(shat)
}


calculate.alphabeta.tau = function(pos, u0, alpha0, beta0, taumax = 2)
{
  tauvec = linspace(0, taumax, 101)
  Jopt = Inf
  tauopt = NA
  for(tau in tauvec)
  {
    u = delay.signal(u0, tau)
    J = optim(par = c(alpha0, beta0), function(x) norm(as.matrix(pos - x[2]*cumsum(u) + cumsum(exponential.model(x[2]*u, x[1]))), "F"), 
              method = "L-BFGS-B", lower = c(0,0), upper = c(1,Inf))$value
    if(J < Jopt) {
      Jopt = J
      tauopt = tau
    }
  }
  u = delay.signal(u0, tauopt)
  
  return( c(optim(par = c(alpha0, beta0), function(x) norm(as.matrix(pos - x[2]*cumsum(u) + cumsum(exponential.model(x[2]*u, x[1]))), "F"), 
                  method = "L-BFGS-B", lower = c(0,0), upper = c(1,Inf))$par, 
            tauopt) )
  
}


calculate.alphabeta.MLE = function(pos, u, N, alpha0, beta0)
{
  rhom = function(x) ( cumsum(u)/x[2] - cumsum(exponential.model(u/x[2], x[1])) )  #Model for rho[n]
  L = function(x) ( -prod(pmax(dbinom(round(N*pos), N, rhom(x) ), 1E-12) ) )
  
  p = optim(par = c(alpha0, 1/beta0), L, method = "L-BFGS-B", lower=0, upper = 1 )
  return(p)
}

at = function(x,i)
{
  if(i <= 0)
    return(0)
  else if(i > length(x))
    return(x[length(x)])
  else
    return(x[i])
}
# 
# delay.signal = function(x, tau)
# {
#   f = tau - floor(tau)
#   y = rep(0, length(x))
#   for(i in 1:length(y))
#   {
#     if(i - ceil(tau) >= 1)
#       y[i] = (1-f)*x[i - floor(tau)] + f*x[i - ceil(tau)]
#     else if(i - floor(tau) >= 1)
#       y[i] = (1-f)*x[i - floor(tau)]
#   }
#   
#   return(y)
# }


delay.signal = function(x, tau)
{
  f = tau - floor(tau)
  y = rep(0, length(x))
  for(i in 1:length(y))
  {
    y[i] = (1-f)*at(x, i - floor(tau)) + f*at(x, i - ceil(tau))
  }
  
  return(y)
}

prev.bootstrap = function(posc)
{
  #sigma = 0.5*(posc$ci_u - posc$ci_l)/1.959963984540054
  #mu = 0.5*(posc$ci_u + posc$ci_l)

  #prev = sapply(1:length(mu), function(i) rnorm(1, mu[i], sigma[i]))
  gamma = -1 + (posc$prev*(1-posc$prev))/posc$var
  alpha = posc$prev*gamma
  beta = gamma - alpha
  
  prev = sapply(1:length(alpha), function(i) ifelse(alpha[i] == 0, 0, rbeta(1, alpha[i], beta[i])))
  
  return( data.frame(donmo = posc$donmo, location = posc$location, n = posc$n, prev = prev))
}


calculate.alphabeta.tau2 = function(pos, u0, alpha1, beta0, taumax = 2)
{
  tauvec = linspace(0, taumax, 11)
  Jopt = Inf
  tauopt = NA
  tau2opt = NA
  
  for(tau in tauvec)
  {
    for(tau2 in tauvec) {
      u = delay.signal(u0, tau)
      J = optim(par = c(alpha1, beta0), function(x) norm(as.matrix(pos - x[2]*cumsum(u) + cumsum(gamma.model(x[2]*u, x[1], tau2))), "F"))$value
      if(J < Jopt) {
        Jopt = J
        tauopt = tau
        tau2opt = tau2
      }
    }
  }
  u = delay.signal(u0, tauopt)
  return( c(optim(par = c(alpha1, beta0), 
                  function(x) norm(as.matrix(pos - x[2]*cumsum(u) + cumsum(gamma.model(x[2]*u, x[1], tau2opt))), "F"))$par, tauopt, tau2opt) )
  
}

calculate.alphabeta.tau3 = function(pos, u0, alpha0, beta0, taumax = 2)
{
  tauvec = linspace(0, taumax, 101)
  Jopt = Inf
  tauopt = NA
  for(tau in tauvec)
  {
    u = delay.signal(u0, tau)
    J = optim(par = c(alpha0, beta0), function(x) norm(as.matrix(pos - x[2]*cumsum(u) + cumsum(exponential.model.delay(x[2]*u, x[1]))), "F"),
              method = "L-BFGS-B", lower = c(0,0), upper = c(1,Inf))$value
    if(J < Jopt) {
      Jopt = J
      tauopt = tau
    }
  }
  u = delay.signal(u0, tauopt)
  return( c(optim(par = c(alpha0, beta0), function(x) norm(as.matrix(pos - x[2]*cumsum(u) + 
                                                                       cumsum(exponential.model.delay(x[2]*u, x[1]))), "F"),
                  method = "L-BFGS-B", lower = c(0,0), upper = c(1,Inf))$par, tauopt) )
  
}



calculate.alphabeta.tau4 = function(pos, u0, alpha0, beta0, taumax = 2)
{
  tauvec = linspace(0, taumax, 101)
  Jopt = Inf
  tauopt = NA
  for(tau in tauvec)
  {
    u = delay.signal(u0, tau)
    J = optim(par = c(alpha0, beta0), function(x) norm(as.matrix(pos - x[2]*cumsum(u) + cumsum(exponential.model(x[2]*u, x[1]))), "F"), 
              method = "L-BFGS-B", lower = c(0,0), upper = c(1,Inf))$value
    if(J < Jopt) {
      Jopt = J
      tauopt = tau
    }
  }
  u = delay.signal(u0, tauopt)
  
  return( c(optim(par = c(alpha0, beta0), function(x) norm(as.matrix(pos - x[2]*cumsum(u) + cumsum(exponential.model(x[2]*u, x[1]))), "F"), 
                  method = "L-BFGS-B", lower = c(0,0), upper = c(1,Inf))$par, 
            tauopt) )
  
}


# prevalence.corrections = function(posc, cases_MN, cases_SP, pop_MN, pop_SP)
# {
#   pos_SP = (posc %>% dplyr::filter(location == "Sao Paulo"))$prev
#   N_SP = (posc %>% dplyr::filter(location == "Sao Paulo"))$n
#   names(pos_SP) = (posc %>% dplyr::filter(location == "Sao Paulo"))$donmo
#   
#   pos_MN = (posc %>% dplyr::filter(location == "Manaus"))$prev
#   N_MN = (posc %>% dplyr::filter(location == "Manaus"))$n
#   names(pos_MN) = (posc %>% dplyr::filter(location == "Manaus"))$donmo
#   
#   # --- Simple Correction --- #
#   
#   alphamin_MN = calculate.alphamin(pos_MN[2:length(pos_MN)])
#   alphamin_SP = calculate.alphamin(pos_SP[2:length(pos_MN)])
#   
#   u_MN_MN = calculate.u(pos_MN[2:length(pos_MN)], alphamin_MN)
#   u_SP_MN = calculate.u(pos_SP[2:length(pos_SP)], alphamin_MN)
#   u_SP_SP = calculate.u(pos_SP[2:length(pos_SP)], alphamin_SP)
#   
#   # --- Correction using SRAG data --- #
#   
#   u_MN = cases_MN$n/pop_MN
#   p = calculate.alphabeta.tau(pos_MN[1:6], u_MN[1:6], 0.42, 364)
#   alpha_MN = p[1]
#   beta_MN = p[2]
#   tau_MN = p[3]
#   ud_MN = delay.signal(u_MN, tau_MN)
#   poshat_MN = cumsum(beta_MN*ud_MN) - cumsum(exponential.model(beta_MN*ud_MN, alpha_MN))
#   
#   u_SP = cases_SP$n/pop_SP
#   p = calculate.alphabeta.tau(pos_SP[1:6], u_SP[1:6], 0.42, 364, 1)
#   alpha_SP = p[1]
#   beta_SP = p[2]
#   tau_SP = p[3]
#   ud_SP = delay.signal(u_SP[1:6], tau_SP)
#   poshat_SP = cumsum(beta_SP*ud_SP) - cumsum(exponential.model(beta_SP*ud_SP, alpha_SP))
#   
#   outfields = c("alphamin_MN", "alphamin_SP", "u_MN_MN", "u_SP_MN", "u_SP_SP", )
#   
#   return(list("alphamin_MN" = alphamin_MN, "alphamin_SP" = alphamin_SP, "u_MN_MN" = u_MN_MN, "u_SP_MN" =    "alpha_MN" = alpha_MN, "beta_MN" = beta_MN, "tau_MN" = tau_MN, "poshat_MN" = poshat_MN, ))
# }
