library(lubridate)
library(dplyr)
library(ggplot2)
library(readxl)
library(writexl)
setwd(getSrcDirectory(function(x) {x}))
source("prevalenceFunctions.R")

pop_MN = 2219580   #IBGE Cidades 2020 -  https://cidades.ibge.gov.br/brasil/am/manaus/panorama
pop_SP = 12325232  #IBGE Cidades 2020 -  https://cidades.ibge.gov.br/brasil/sp/sao-paulo/panorama
dates = (seq(as.Date("2020-03-01"),length=7,by="months")-1)

df = read_excel("HIST_PAINEL_COVIDBR_04set2020.xlsx")
df = df %>% filter( (ymd(data) %in% dates) & (municipio %in% c("Manaus", "São Paulo"))) %>%
  mutate(donmo = month(data)) %>% select("donmo", "municipio", "casosAcumulado") %>% 
  rename("location" = "municipio", "confirmed" = "casosAcumulado" )
df$location[df$location == "São Paulo"] = "Sao Paulo"

df$pop = NA
df$pop[df$location == "Sao Paulo"] = pop_SP
df$pop[df$location == "Manaus"] = pop_MN
df$cases_per_capita = df$confirmed/df$pop

# --- Threshold = 1.4 --- #

posc = correctedPrevalence(smallthresh = FALSE, adjustspec = TRUE)
dff = df %>% left_join(posc %>% select("donmo", "location", "prev", "ci_l", "ci_u")) %>% arrange(location, donmo)

dff$subnotif.est = dff$prev/dff$cases_per_capita
dff$subnotif.cil = dff$ci_l/dff$cases_per_capita
dff$subnotif.ciu = dff$ci_u/dff$cases_per_capita

g1 = ggplot(dff %>% filter(donmo >= 4), 
       aes(x = donmo, y = subnotif.est, fill = location)) + geom_crossbar(aes(ymin = subnotif.cil, ymax = subnotif.ciu), position = "dodge") +
      theme_bw() + xlab("Month") + ylab("Undernotification Rate") + ylim(c(0, 65)) + ggtitle("Undernotification Rate (Threshold = 1.4)")
ggsave("undernotif_thr14.png", g1)
write_xlsx(dff, "undernotif_thr14.xlsx")

# --- Threshold = 0.4 --- #

posc = correctedPrevalence(smallthresh = TRUE, adjustspec = TRUE)
dff = df %>% left_join(posc %>% select("donmo", "location", "prev", "ci_l", "ci_u")) %>% arrange(location, donmo)

dff$subnotif.est = dff$prev/dff$cases_per_capita
dff$subnotif.cil = dff$ci_l/dff$cases_per_capita
dff$subnotif.ciu = dff$ci_u/dff$cases_per_capita

g2 = ggplot(dff %>% filter(donmo >= 4), 
            aes(x = donmo, y = subnotif.est, fill = location)) + geom_crossbar(aes(ymin = subnotif.cil, ymax = subnotif.ciu), position = "dodge") +
  theme_bw() + xlab("Month") + ylab("Undernotification Rate") + ylim(c(0, 65)) + ggtitle("Undernotification Rate (Threshold = 0.4)")
ggsave("undernotif_thr04.png", g2)
write_xlsx(dff, "undernotif_thr04.xlsx")

# --- Corrected Prevalence --- #

load("CorrecaoPositividade_10k.RData")
posc = rbind(data.frame(donmo = 3:8, location = "Sao Paulo", prev = U_SP_MN.est, ci_l = U_SP_MN.cil, ci_u = U_SP_MN.ciu), 
             data.frame(donmo = 3:8, location = "Manaus", prev = U_MN_MN.est, ci_l = U_MN_MN.cil, ci_u = U_MN_MN.ciu))
dff = df %>% left_join(posc) %>% arrange(location, donmo)

dff$subnotif.est = dff$prev/dff$cases_per_capita
dff$subnotif.cil = dff$ci_l/dff$cases_per_capita
dff$subnotif.ciu = dff$ci_u/dff$cases_per_capita

g3 = ggplot(dff %>% filter(donmo >= 4), 
            aes(x = donmo, y = subnotif.est, fill = location)) + geom_crossbar(aes(ymin = subnotif.cil, ymax = subnotif.ciu), position = "dodge") +
  theme_bw() + xlab("Month") + ylab("Undernotification Rate") + ylim(c(0, 65)) + ggtitle("Undernotification Rate (Corrected Prevalence)")
ggsave("undernotif_corrected.png", g3)
write_xlsx(dff, "undernotif_corrected.xlsx")


